//
//  FavoriteTableViewController.h
//  BookMyShowDemo
//
//  Created by AshU on 9/4/15.
//  Copyright (c) 2015 Ashish Khobragade. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoriteTableViewController : UITableViewController

@end
